--1. Store KPI Procedure
CREATE OR ALTER PROCEDURE GetStoreKPI
    @StoreID INT,
    @Year INT
AS
BEGIN
    SELECT 
        s.store_name,
        COUNT(o.order_id) AS total_orders,
        SUM(oi.list_price * oi.quantity * (1 - oi.discount)) AS annual_revenue
    FROM sales.stores s
    JOIN sales.orders o ON s.store_id = o.store_id
    JOIN sales.order_items oi ON o.order_id = oi.order_id
    WHERE s.store_id = @StoreID 
      AND YEAR(o.order_date) = @Year
    GROUP BY s.store_name;
END;
-- To run: EXEC GetStoreKPI @StoreID = 1, @Year = 2024;

--2. Restock List Procedure

CREATE OR ALTER PROCEDURE GetRestockList
    @Threshold INT
AS
BEGIN
    SELECT 
        p.product_name,
        s.store_name,
        st.quantity AS current_stock
    FROM production.products p
    JOIN production.stocks st ON p.product_id = st.product_id
    JOIN sales.stores s ON st.store_id = s.store_id
    WHERE st.quantity < @Threshold
    ORDER BY st.quantity ASC;
END;
-- To run: EXEC GetRestockList @Threshold = 10;

--3. Year-over-Year Comparison Procedure

	CREATE OR ALTER PROCEDURE GetYearlyComparison
    @Year1 INT,
    @Year2 INT
AS
BEGIN
    SELECT 
        COALESCE(Y1.Category, Y2.Category) AS Category,
        ISNULL(Y1.Revenue, 0) AS Revenue_Year_1,
        ISNULL(Y2.Revenue, 0) AS Revenue_Year_2,
        ISNULL(Y2.Revenue, 0) - ISNULL(Y1.Revenue, 0) AS Difference
    FROM 
        (SELECT c.category_name AS Category, SUM(oi.list_price * oi.quantity) AS Revenue 
         FROM production.categories c 
         JOIN production.products p ON c.category_id = p.category_id
         JOIN sales.order_items oi ON p.product_id = oi.product_id
         JOIN sales.orders o ON oi.order_id = o.order_id
         WHERE YEAR(o.order_date) = @Year1 GROUP BY c.category_name) Y1
    FULL OUTER JOIN 
        (SELECT c.category_name AS Category, SUM(oi.list_price * oi.quantity) AS Revenue 
         FROM production.categories c 
         JOIN production.products p ON c.category_id = p.category_id
         JOIN sales.order_items oi ON p.product_id = oi.product_id
         JOIN sales.orders o ON oi.order_id = o.order_id
         WHERE YEAR(o.order_date) = @Year2 GROUP BY c.category_name) Y2
    ON Y1.Category = Y2.Category;
END;
-- To run: EXEC GetYearlyComparison @Year1 = 2023, @Year2 = 2024;

--4. Customer Profile Procedure

CREATE OR ALTER PROCEDURE GetCustomerProfile
    @CustomerID INT
AS
BEGIN
    SELECT 
        c.first_name + ' ' + c.last_name AS customer_name,
        COUNT(o.order_id) AS total_orders,
        SUM(oi.list_price * oi.quantity) AS total_spent,
        MAX(cat.category_name) AS favorite_category
    FROM sales.customers c
    JOIN sales.orders o ON c.customer_id = o.customer_id
    JOIN sales.order_items oi ON o.order_id = oi.order_id
    JOIN production.products p ON oi.product_id = p.product_id
    JOIN production.categories cat ON p.category_id = cat.category_id
    WHERE c.customer_id = @CustomerID
    GROUP BY c.first_name, c.last_name;
END;
-- To run: EXEC GetCustomerProfile @CustomerID = 5;
EXEC GetCustomerProfile @CustomerID = 5