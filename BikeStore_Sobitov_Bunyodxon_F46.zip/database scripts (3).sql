CREATE DATABASE BikeStore8
GO 
USE BikeStore8;
go

--CREATING SCHEMAS
CREATE SCHEMA sales;
go

CREATE SCHEMA Prod;
go


-- CONTINUING SALES SCHEMAS;

DROP TABLE IF EXISTS sales.Customers;
go
CREATE TABLE Sales.Customers
(
   customer_id int primary key
  ,first_name varchar(50)
  ,last_name varchar(50)
  ,phone varchar(50)
  ,email varchar(100)
  ,street varchar(100)
  ,city varchar(100)
  ,state varchar(50)
  ,zip_code int
);
go


DROP TABLE IF EXISTS Sales.Orders;
go
CREATE TABLE sales.Orders
(
   order_id int primary key
  ,customer_id int 
  ,order_status int
  ,order_date datetime
  ,required_date datetime
  ,shipped_date datetime
  ,store_id int
  ,staff_if int
);
go

DROP TABLE IF EXISTS Sales.Staffs;
go
CREATE TABLE sales.Staffs
(
   staff_id int primary key
  ,first_name varchar(50)
  ,last_name varchar(50)
  ,email varchar(100)
  ,phone varchar(50)
  ,active bit
  ,store_id int
  ,manager_id int
);
go



DROP TABLE IF EXISTS Sales.Stores
CREATE TABLE sales.Stores
(
   store_id int primary key
  ,store_name varchar(100)
  ,phone varchar(50)
  ,email varchar(100)
  ,street varchar(100)
  ,city varchar(100)
  ,state varchar(50)
  ,zip_code int
);
go



DROP TABLE IF EXISTS Sales.Order_items;
go
CREATE TABLE sales.Order_items
(
   order_id int 
  ,item_id int
  ,product_id int
  ,quantity int
  ,list_price decimal(10,2)
  ,discount decimal(4,2)
  ,primary key (order_id, item_id)
);
go



-- CONTINUING Prod (Production) SCHEMAS;

DROP TABLE IF EXISTS Prod.Categories;
go
CREATE TABLE Prod.Categories
(
	category_id int primary key,
	category_name varchar(100)
);
go


DROP TABLE IF EXISTS Prod.Brands;
go
CREATE TABLE Prod.Brands
(
	 brand_id int primary key
	,brand_name varchar(100)
);
go

DROP TABLE IF EXISTS Prod.Products;
go
CREATE TABLE Prod.Products
(
	 product_id int primary key
	,product_name varchar(100)
	,brand_id int
	,category_id int
	,model_year int
	,list_price decimal(10,2)
);
go

DROP TABLE IF EXISTS Prod.Stocks;
go
CREATE TABLE Prod.Stocks
(
	 store_id int
	,product_id int
	,quantity int
	,primary key (store_id, product_id)
);

go


-- FOREIGN KEYS (ALTER TABLE)


ALTER TABLE Sales.Orders
ADD FOREIGN KEY (customer_id) REFERENCES Sales.Customers(customer_id),
	FOREIGN KEY (store_id) REFERENCES Sales.Stores(store_id),
	FOREIGN KEY (staff_if) REFERENCES Sales.Staffs(staff_id)

go

ALTER TABLE Sales.Staffs
ADD FOREIGN KEY (store_id) REFERENCES Sales.Stores(store_id),
	FOREIGN KEY (manager_id) REFERENCES Sales.Staffs(staff_id);
go

ALTER TABLE Sales.Order_items
ADD FOREIGN KEY (order_id) REFERENCES Sales.Orders(order_id),
	FOREIGN KEY (product_id) REFERENCES Prod.Products(product_id);
go

ALTER TABLE Prod.Products
ADD FOREIGN KEY (brand_id) REFERENCES Prod.Brands(brand_id),
	FOREIGN KEY (category_id) REFERENCES Prod.Categories(category_id);
go

ALTER TABLE Prod.Stocks
ADD FOREIGN KEY (store_id) REFERENCES Sales.Stores(store_id),
	FOREIGN KEY (product_id) REFERENCES Prod.Products(product_id);
go
	