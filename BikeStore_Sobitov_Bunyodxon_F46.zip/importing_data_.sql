
  -- SALES SCHEMA STAGING TABLES

  CREATE TABLE #_staging_Customers
  (
     customer_id int,
     first_name nvarchar(255),
     last_name nvarchar(255),
     phone nvarchar(255),
     email nvarchar(255),
     street nvarchar(255),
     city nvarchar(255),
     state nvarchar(255),
     zip_code int
  );

  CREATE TABLE #_staging_Orders
  (
     order_id int,
     customer_id int,
     order_status int,
     order_date nvarchar(255),
     required_date nvarchar(255),
     shipped_date nvarchar(255),
     store_id int,
     staff_if int
  );

  CREATE TABLE #_staging_Staffs
  (
     staff_id int,
     first_name nvarchar(255),
     last_name nvarchar(255),
     email nvarchar(255),
     phone nvarchar(255),
     active int,
     store_id int,
     manager_id nvarchar(255)
  );

  CREATE TABLE #_staging_Stores
  (
     store_id int,
     store_name nvarchar(255),
     phone nvarchar(255),
     email nvarchar(255),
     street nvarchar(255),
     city nvarchar(255),
     state nvarchar(255),
     zip_code int
  );

  CREATE TABLE #_staging_Order_items
  (
     order_id int,
     item_id int,
     product_id int,
     quantity int,
     list_price nvarchar(255),
     discount nvarchar(255)
  );

  
 
 -- PROD SCHEMA STAGING TABLES

  CREATE TABLE #_staging_Categories
  (
     category_id int,
     category_name nvarchar(255)
  );

  CREATE TABLE #_staging_Brands
  (
     brand_id int,
     brand_name nvarchar(255)
  );

  CREATE TABLE #_staging_Products
  (
     product_id int,
     product_name nvarchar(255),
     brand_id int,
     category_id int,
     model_year int,
     list_price nvarchar(255)
  );

  CREATE TABLE #_staging_Stocks
  (
     store_id int,
     product_id int,
     quantity int
  );

  -- BULK INSERT INTO STAGING TABLES

  BULK INSERT #_staging_Customers
  FROM 'D:\SQL_homeworks\projects\customers.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Orders
  FROM 'D:\SQL_homeworks\projects\orders.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Staffs
  FROM 'D:\SQL_homeworks\projects\staffs.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Stores
  FROM 'D:\SQL_homeworks\projects\stores.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Order_items
  FROM 'D:\SQL_homeworks\projects\order_items.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Categories
  FROM 'D:\SQL_homeworks\projects\categories.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Brands
  FROM 'D:\SQL_homeworks\projects\brands.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Products
  FROM 'D:\SQL_homeworks\projects\products.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

  BULK INSERT #_staging_Stocks
  FROM 'D:\SQL_homeworks\projects\stocks.csv'
  WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

-- TRANSFORMATIONS(UPDATE): TEXT "NULL" --> NULL

  UPDATE #_staging_Customers
  set phone = null
  where phone = 'null'

  UPDATE #_staging_Orders
  set shipped_date = null
  where shipped_date = 'null'
  
  UPDATE #_staging_Staffs
  set manager_id = null
  where  manager_id = 'null'

  /*
  ==========================
  ==========================  
  */

