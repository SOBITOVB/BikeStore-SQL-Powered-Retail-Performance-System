--1. Jami tushum (Total Revenue)

SELECT 
    SUM(quantity * list_price * (1 - discount)) AS Total_Revenue
FROM sales.order_items;

--2. O'rtacha buyurtma qiymati (AOV - Average Order Value)


SELECT 
    SUM(quantity * list_price * (1 - discount)) / COUNT(DISTINCT order_id) AS AOV
FROM sales.order_items;

--3. Inventar aylanishi (Inventory Turnover)

SELECT 
    CAST((SELECT SUM(quantity) FROM sales.order_items) AS FLOAT) / 
    (SELECT SUM(quantity) FROM production.stocks) AS Inventory_Turnover;


--4. Do'konlar bo'yicha tushum (Revenue by Store)

SELECT 
    s.store_name, 
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Revenue
FROM sales.stores s
JOIN sales.orders o ON s.store_id = o.store_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY s.store_name;

--5. Kategoriya bo'yicha foyda (Profit by Category)

SELECT 
    c.category_name, 
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Category_Revenue
FROM production.categories c
JOIN production.products p ON c.category_id = p.category_id
JOIN sales.order_items oi ON p.product_id = oi.product_id
GROUP BY c.category_name;


--6. Brendlar bo'yicha savdo (Sales by Brand)


SELECT 
    b.brand_name, 
    SUM(oi.quantity) AS Units_Sold
FROM production.brands b
JOIN production.products p ON b.brand_id = p.brand_id
JOIN sales.order_items oi ON p.product_id = oi.product_id
GROUP BY b.brand_name;

--7. Xodimlar hissasi (Staff Contribution)

SELECT 
    st.first_name + ' ' + st.last_name AS Staff_Name,
    SUM(oi.quantity * oi.list_price * (1 - oi.discount)) AS Total_Sales
FROM sales.staffs st
JOIN sales.orders o ON st.staff_id = o.staff_id
JOIN sales.order_items oi ON o.order_id = oi.order_id
GROUP BY st.first_name, st.last_name;



